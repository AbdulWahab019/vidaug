import cv2
import numpy as np
import os

from PIL import Image, ImageSequence
import vidaug.augmentors as va

def image_loader(path, modality="RGB")
    frames = []
    with open(path, 'rb') as f:
        with Image.open(f) as video:
            index = 1
            for frame in ImageSequence.Iterator(video):
                frames.append(frame.convert(modality))
                index += 1
        return frames

frames = image_loader("C:\Users\wahab\Desktop\FYP\3D_data\v1")

frames[0]

sometimes = lambda aug: va.Sometimes(1, aug) # Used to apply augmentor with 100% probability
seq = va.Sequential([ # randomly rotates the video with a degree randomly choosen from [-10, 10]  
    sometimes(va.HorizontalFlip()) # horizontally flip the video with 100% probability
])

video_aug = seq(frames)

video_aug[0].save("1.mp4", save_all=True, append_images=video_aug[1:], duration=100, loop=0)